def draw_square(size):
    """Return a filled square of '*' characters."""
    pass

def draw_triangle(height):
    """Return a right triangle of '*' characters."""
    pass

def draw_hollow_rectangle(width, height):
    """Return a hollow rectangle of '*' characters."""
    pass
