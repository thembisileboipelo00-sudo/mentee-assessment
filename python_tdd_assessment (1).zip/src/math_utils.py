# src/math_utils.py

# TODO: Implement the following functions with basic math operations.
# Each should handle invalid input gracefully.

def add(a, b):
    # TODO: Return the sum of a and b
    pass

def subtract(a, b):
    # TODO: Return the difference between a and b
    pass

def multiply(a, b):
    # TODO: Return the product of a and b
    pass

def divide(a, b):
    # TODO: Return the quotient of a / b, handle division by zero with ValueError
    pass
