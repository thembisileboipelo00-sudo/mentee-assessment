# src/list_utils.py

# TODO: Implement list filtering helpers

def filter_even(numbers):
    # TODO: Return only even numbers
    pass

def filter_positive(numbers):
    # TODO: Return only positive numbers
    pass
