# Implement the following functions so all tests pass

def add_numbers(a, b):
    pass

def is_even(num):
    pass

def reverse_string(text):
    pass

def factorial(n):
    """
    Return the factorial of n using recursion or a loop.
    Raise ValueError if n is negative.
    """
    pass

def calculate_discount(price, percentage):
    """
    Returns the discounted price (price - percentage%)
    Raise ValueError for negatives
    Cap discount at 90%
    """
    pass
