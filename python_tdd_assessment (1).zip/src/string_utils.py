# src/string_utils.py

# TODO: Implement string formatting helpers

def format_name(first, last):
    # TODO: Return "Last, First"
    pass

def title_case(sentence):
    # TODO: Convert sentence to title case (capitalize first letter of each word)
    pass
